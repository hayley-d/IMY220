import React from "react"
import ReactDOM from "react-dom";

import {PersonList} from "./components/PersonList.js";

ReactDOM.render(<PersonList />, document.getElementById("root"));
