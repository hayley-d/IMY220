import React from "react";

import {Person} from "./Person";
import {AddPersonForm} from "./AddPersonForm";

export class PersonList extends React.Component{
  //some code here
}
