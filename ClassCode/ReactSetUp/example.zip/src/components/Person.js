import React from "react";
import PropTypes from 'prop-types';

export class Person extends React.Component{

  render(){
      return(
          <li> { `${this.props.name} ${this.props.person.surname}`} </li>
      );
  }
}

Person.propTypes = {
    person: PropTypes.object
}
