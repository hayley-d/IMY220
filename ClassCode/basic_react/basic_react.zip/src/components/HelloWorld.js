//Hayley Dodkins u21528790
import React from 'react';

export class HelloWorld extends React.Component{
    
    render(){
        return(
            <div>
                <h5>Hayley Dodkins</h5>
                <p>u21528790</p>
            </div>
        );
    }
}
